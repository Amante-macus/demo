package homework;
import java.util.Scanner;
public class Homework5 {

	public static void main(String[] args) {
		System.out.println("�������·ݣ�");
		Scanner scanner = new Scanner(System.in);
		int month = scanner.nextInt();
		
		if (month>=3&&month<=5) {
			System.out.println("����");
		} else if(month>=6&&month<=8){
			System.out.println("�ļ�");
		} else if(month>=9&&month<=11){
			System.out.println("�＾");
		} else if((month==12)||(month>=1&&month<=2)){
			System.out.println("����");
		} else {
			System.out.println("���벻�Ϸ�");
		}
		
//		switch (month) {
//		case 2:
//		case 3:
//		case 4:
//			System.out.println("����");		
//			break;
//		case 5:
//		case 6:
//		case 7:
//			System.out.println("�ļ�");
//			break;
//		case 8:
//		case 9:
//		case 10:
//			System.out.println("�＾");
//			break;
//		case 11:
//		case 12:
//		case 1:
//			System.out.println("����");
//			break;
//		}
	}	


}
