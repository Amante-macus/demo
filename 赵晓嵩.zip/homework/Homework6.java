package homework;

public class Homework6 {
	public static void main(String[] args) {
		long current = System.currentTimeMillis();
		long time=current/1000;
        long hour =time/3600%24+8;
		long minutes =time/60%60;
		long seconds =time%60;
		System.out.println(hour+":"+minutes+":"+seconds);
	}

}
