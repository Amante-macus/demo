package homework;
import java.util.Scanner;
public class Homework1 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		double money = input.nextDouble();
		double salary=0;
		if(money-3500<=500)
			salary=3500+(money-3500)*0.95;
		else if(money-3500<=2000)
			salary=3500+500*0.95+(money-4000)*0.9+25;
		else if(money-3500<=5000)
			salary=3500+500*0.95+1500*0.9+(money-5500)*0.85+125;
		else if(money-3500<=20000)
			salary=3500+500*0.95+1500*0.9+3000*0.85+(money-8500)*0.8+375;
		else if(money-3500<=40000)
			salary=3500+500*0.95+1500*0.9+3000*0.85+15000*0.8+(money-23500)*0.75+1375;
		else if(money-3500<=60000)
			salary=3500+500*0.95+1500*0.9+3000*0.85+15000*0.8+20000*0.75+(money-43500)*0.7+3375;
		else if(money-3500<=80000)
			salary=3500+500*0.95+1500*0.9+3000*0.85+15000*0.8+20000*0.75+20000*0.7+(money-63500)*0.65+6375;
		else if(money-3500<=100000)
			salary=3500+500*0.95+1500*0.9+3000*0.85+15000*0.8+20000*0.75+20000*0.7+20000*0.65+(money-83500)*0.6+10375;
		else if(money-3500>100000)
			salary=3500+500*0.95+1500*0.9+3000*0.85+15000*0.8+20000*0.75+20000*0.7+20000*0.65+20000*0.6+(money-103500)*0.55+15375;
		System.out.println(salary);
		input.close();
	}

}
