package homework;

import java.util.Scanner;

public class HomeWork3 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("����������");
		int grade = input.nextInt();
		String prize = null;
		switch(grade) {
		case 1:
			prize="IPHONE 8";
			break;
		case 2:
			prize="IPHONE 7";
			break;	
		case 3:
			prize="IPHONE 6";
			break;		
		case 4:
			prize="IPHONE 5";
			break;		
		default:
			prize="Ŭ����";
			break;
		}
		System.out.println(prize);
		input.close();
	}
}
