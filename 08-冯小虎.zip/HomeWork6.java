package homework;


import java.util.Scanner;


public class HomeWork6 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("������һ���·ݣ�");
		Scanner input = new Scanner(System.in);
		int month = input.nextInt();
		switch(month) {
		case 1:
		case 2:
		case 3:
			System.out.println("����");
			break;
		case 4:
		case 5:
		case 6:
			System.out.println("����");
			break;
		case 7:
		case 8:
		case 9:
			System.out.println("����");
			break;
		case 10:
		case 11:
		case 12:
			System.out.println("����");
			break;
		default:
			System.out.println("�·ݲ��Ϸ�");
			break;	
		}
		input.close();

	}
}
