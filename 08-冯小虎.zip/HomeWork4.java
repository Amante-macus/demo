package homework;


public class HomeWork4 {
	public static void main(String[] args) {
		long current = System.currentTimeMillis();//���뼶���
		long time=current/1000;//ת��Ϊ��Ϊ��λ
        long hour =time/3600%24+8;//һ��24h,ʱ��+8
		long minutes =time/60%60;
		long seconds =time%60;
		System.out.println(hour+":"+minutes+":"+seconds);
	}
}
